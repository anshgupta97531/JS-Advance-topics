// ----------------------------------JAVASCRIPT----------------------------------//
// ------------------------- DAY 1  ------------------------//
// ------------------------- all imp functions in array ------------------------//

// -------------------------------- forEach --------------------------------
/*var arr=[1,2,3,4]; 
arr.forEach(function(val){
    console.log(val + " hello");

    /* forEach ek higher order function ha ,jo ap ki given array ke har element per kuch operation perform ker ta ha 
        ek ke ker ke , ja nayi array return nhi ker ta bus har element per operation perform ker ta h.
})*/

// -------------------------------- map --------------------------------------

/*var arr = [1,2,3,4,5];
var ans = arr.map((val)=>{
    return val + 10;
})
console.log(ans);*/

/* Map ek higher order function h ,jo forEach ki tarah kam ker ta ha ,jase ki array ke har element per
jata ha un per operation perform ker ta ha aur ek nayi array return ker ta h.*/

// -------------------------------- Filter --------------------------------------
/*var arr=[1,2,3,4,5];

var ans = arr.filter((val)=>{
    if(val >= 3){return true;}
    else false
})
console.log(ans);*/

/* filter ek function ha jo map ki tarah ek array return ker ta ha ,lakin kuch filter (<,>,===) apply ker ne ke bad 
, ya filter function array ke har element pe filter apply ho ta h phir array ke form me output deta h . */

// -------------------------------- Find --------------------------------------
/*var arr = [1,2,2,3,4,5];
var ans = arr.find((val)=>{
    if(val===4)return val;
})
console.log(ans);*/

// Find ek function ha jo given array ke 1st element dete ha filter ke hisab se ek naye array ke form me.

// -------------------------------- indexOf --------------------------------------

/*var arr = [1,2,3,4,5]

var ans = arr.indexOf(4);
console.log(ans);*/

//indexOf ke use tab hota ha jab apan ko koi element dek na ho ki ya particular element present ha ya nhi array me.
// present nhi ho ga to -1 de de ga aur agar present ho ga to index value de de ga us element ki. 


// ---------------------- Objects in js ----------------------------------------//
/*var obj = {
    name:"ansh",
    age:13
}
console.log(obj.name,obj.age);*/
//Object.freeze(obj); // ya line islia use hui h taki apan apne objects ki value ko chane na ker sake

//objects hmase se {} in brakets ko use ker ke bante h .

// ------------------- asyn coding in js ----------------------------------------//

/*1. agar code ap ka line by line chale to us ka matlab  synchronous hota ha.

2. jo bhi code asyn nature ka ho usse side stack me dal do aur baki ka syn nature ka code ko execute karo matlab main stack ke empty karo aur deko ki asyn nature ke code complete hua ki nhi agr complete  ho gaya to usse main stack me dal do aur chalo.*/

/*async function users(){
    var blob = await fetch(`https://randomuser.me/api/`);
    var ans = await blob.json();

    console.log(ans.results);
}

users();*/

// agar hme koi bhi function ko asynchronous bana na ho to hm function ke phela 'async' keyword ke use karenge , await ek asyn code like na ka tarika ha is ke use ha ki koi data hm log agar live server se fetch ker rehe honge to awit vali line side stck me chali jaegi aur main stack ke empty hone per vo side stack ke main stack me ayegi.

// ------------------- promices in js ----------------------------------------//

/*
promices ek esa function h jo do parameter leta h resolve aur reject is ka matlab h ki jab ap ki if vali condition true ho jati h to resolve chal ta ha aur resolve ke sath 
.then function bhi chal ta ha  

aur agar if vali condition false hoti ha to reject chal ta ha aur sath me .cath function bhi chal ta h. 

const ticket = new Promice((resolve,reject)=>{
    const isBoarded = false;
    if(isBoarded)
    {
        resolve("You are not boarded");
    }
    else{
        reject("Your flight is cancelled");
    }
})

ticket.then((message)=>{
    console.log("Hi sir" + message);
}).catch((message)=>{
    conslole.log("Ohh no" + message);
})*/
