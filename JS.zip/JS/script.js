// ----------------------------------BACKEND----------------------------------//
// ------------------------- DAY 2  ------------------------//

/* STEP 1. npm init -> is ka use hota ha package .json bana ne ke aur package.json apki project ki puri details rak ta h .*/

/*
1. Write file.
2. Append file.
3. Copy file.
4. rename.
5. unlink. 
6. Read file (err,data).*/

// STEP 2 creating server using HTTP
/* HTTP me jab apan code lik te h aur us code ko jab run ker te h terminal me node script.js lik ke to server start hota ha terminal me kuch change nhi hota */


// ------------------------- DAY 3  ------------------------//
 /*
 NPM is Node package manager 
// to download any NPM (both will we written in terminal)

npm i/install package_manager_name.

// to uninstall any NPM 

npm uninstall package_manager_name.
 */

// ------------------------- DAY 4  ------------------------//

/* EXPRESS JS

const express = require('express')
const app = express();
app.get("/",function(req,res){
    res.send("hello");
})

app.get("/profile",function(req,res){
    res.send("hellooooooo");
})

app.listen(3000); 

to run this code node script.js in terminal


// middleware
 middleware ke matlab hota ha h jab apan koi bhi request send ker te ha user side se server side pe to router se phela middleware hota ha jis ks kam kisi bhi type ke opertion perform ker na hota ha us request pe.
 
 const express = require('express')
const app = express();


// MIDDLEWARE
app.use(function(req,res,next){
    console.log("me chal gaya");
    next();
   
})

app.get("/",function(req,res){
    res.send("hello");
})

app.get("/profile",function(req,res){
    res.send("hellooooooo");
})

app.listen(3000); 


// ERROR HANDLING 

const express = require('express')
const app = express();

app.use(function(req,res,next){
    console.log("me chal gaya");
    next();
   
})

app.get("/",function(req,res){
    res.send("hello");
})

app.get("/about",function(req,res,next){
    return next(new Error("This is console error message"))
});

app.use((err,req,res,next)=>{
    console.log(err.stack)
    res.stack(500).send("This is front end error message");
});

app.listen(3000); 


*/

// ------------------------- DAY 5  ------------------------//
/* Form handling 
cookies :- Data which is saved on our front end side. Cookies ka use hm authentication me ker te h 
taki user ek bar login ker ne per hme she ke lia login rehe.

sessions :- login se logout tak ek session hota h.


const express = require('express')
const app = express();

app.use(express.json());
app.use(express.urlencoded({extended:true}));

app.get("/",function(req,res){
    res.send("hello");
})

app.get("/about",function(req,res,next){
    return next(new Error("This is console error message"))
});

app.use((err,req,res,next)=>{
    console.log(err.stack)
    res.stack(500).send("This is front end error message");
});

app.listen(3000); 


*/

// ------------------------- DAY 6  ------------------------//

/*

*/